Readme.txt
Para compilar usar make

L para el modo linea
P para el modo punto
S para el modo sólido con linea
N para activar la animación
M para parar la animación
U para aumentar la velocidad de las animaciones
D para disminuir la velocidad de las animaciones
A para mover el brazo
F para mover el entebrazo
E para mover el ojo


